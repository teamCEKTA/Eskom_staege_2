#mypackage
This library is made to handle data inputs

##building this package locally
'python setup.py sdist'

##installing this package from Github
'pip install git+https://github.com/teamCEKTA/Eskom_staege_2.git'

##updating this package from Github
'pip install --upgrade git+https://github.com/teamCEKTA/Eskom_staege_2.git'